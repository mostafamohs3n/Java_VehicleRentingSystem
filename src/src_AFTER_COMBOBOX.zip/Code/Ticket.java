package Code;
import java.io.Serializable;

public class Ticket implements RecordData, Serializable {

	private String EmailAddress;

	private String Name;

	private double totalPrice;

	private String orderDetails;

	public String getEmailAddress() {
	 	 return EmailAddress; 
	}

	public void setEmailAddress(String EmailAddress) { 
		 this.EmailAddress = EmailAddress; 
	}
	
	public String getName() {
	 	 return Name; 
	}
	
	public void setName(String Name) { 
		 this.Name = Name; 
	}
	
	public double getTotalPrice() {
	 	 return totalPrice; 
	}
	
	public void setTotalPrice(double totalPrice) { 
		 this.totalPrice = totalPrice; 
	}
	
	public String getOrderDetails() {
	 	 return orderDetails; 
	}
	
	public void setOrderDetails(String orderDetails) { 
		 this.orderDetails = orderDetails; 
	}
	
	public boolean appendFileData() {
		return true; 
		// TODO Auto-generated method
	 }
	
	public void loadFileData() { 
		// TODO Auto-generated method
	 } 

}
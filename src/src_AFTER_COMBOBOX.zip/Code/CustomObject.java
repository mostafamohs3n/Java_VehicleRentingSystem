package Code;

import java.util.ArrayList;
import java.util.Arrays;

public class CustomObject {
	public final static ArrayList<String> CarUsage = new ArrayList<String>(Arrays.asList("Taxi", "Individual rent"));
	public final static ArrayList<String> Qualifications = new ArrayList<String>(Arrays.asList("Fresh graduate", "Experienced",  "Experienced student", "Student"));
	public final static ArrayList<String> VehicleType = new ArrayList<String>(Arrays.asList("AC", "Non-AC"));
	public final static ArrayList<String> CarVariant = new ArrayList<String>(Arrays.asList("Base model", "Economic model", "Top model"));



}